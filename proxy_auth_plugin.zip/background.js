
var config = {
    mode: "fixed_servers",
    rules: {
        singleProxy: {
            scheme: "http",
            host: "173.239.219.126",
            port: parseInt("6035")
        },
        bypassList: ["localhost"]
    }
};

chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

chrome.webRequest.onAuthRequired.addListener(
    function(details) {
        return {
            authCredentials: {
                username: "wlhkebmr",
                password: "xcxbfhgvisbs"
            }
        };
    },
    {urls: ["<all_urls>"]},
    ["blocking"]
);
